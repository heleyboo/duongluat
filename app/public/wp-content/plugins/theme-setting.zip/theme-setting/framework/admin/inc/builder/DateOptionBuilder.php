<?php


class DateOptionBuilder extends OptionBuilder
{

    public function buildOption()
    {
        ?>
        <input type="text" name="test1">
        <?php
    }
}