<?php


interface OptionBuilderInterface
{
    /**
     * @return mixed
     */
    public function buildOption();
}