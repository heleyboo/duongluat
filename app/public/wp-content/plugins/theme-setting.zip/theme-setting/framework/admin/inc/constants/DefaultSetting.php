<?php

class DefaultSetting
{
    const TS_LAYOUT_TYPE = 'ts_layout_type';
    const TS_BACKGROUND_PATTERN = 'ts_background_pattern';
}